package com.example.utils;//package utils;
//
//import Service1.Timetable;
//import pojo.*;
//
//import static utils.Constant.*;
//
//public class ParameterGenerator {
//
//
//}
//
//
//
